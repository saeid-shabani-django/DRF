from django.shortcuts import render
from .models import Product,Category,Customer,OrderItem,Order,Comment
from django.db.models import Q,F


def show_store(request):
    q = Product.objects.prefetch_related('orderitems').all()

    return render(request,'store/hello.html',{'products':list(q),
                                                                      })

def show_comments(request):
    # comments = Comment.objects.select_related('product').all()
    # products = Product.objects.prefetch_related('comments').all()
    # new_products = Product.objects.select_related('category').all()
    orderitems = Order.objects.prefetch_related('orderitems').all()
    customers = Order.objects.select_related('customer').all()

    return render(request,'store/comments.html',{'orderitems':orderitems,
                                                                        'customers':customers})
