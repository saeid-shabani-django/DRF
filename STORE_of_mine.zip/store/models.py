from django.core import validators
from django.db import models
from django.core.validators import MinValueValidator

class Category(models.Model):

    title = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    top_product = models.ForeignKey('Product', on_delete=models.SET_NULL, null=True, related_name="+")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = 'categories'

class Discount(models.Model):
    discount = models.FloatField()
    description = models.CharField(max_length=200)



class Product(models.Model):
    description = models.TextField()
    slug = models.SlugField()
    unit_price = models.DecimalField(max_digits=6,decimal_places=2)
    category = models.ForeignKey(Category, on_delete=models.PROTECT,related_name='products')
    inventory = models.IntegerField(validators=[MinValueValidator(1)])
    datetime_created = models.DateTimeField(auto_now_add=True)
    datetime_updated = models.DateTimeField(auto_now=True)
    discounts = models.ManyToManyField(Discount,blank = True)

    def __str__(self):
        return self.description[0:7]





class Customer(models.Model):
    first_name = models.CharField(max_length=120)
    last_name = models.CharField(max_length=120)
    email = models.EmailField()
    phone_number = models.CharField(max_length=70)
    birth_date = models.DateField(null=True)
    def __str__(self):
        return self.first_name


class Address(models.Model):
    province = models.CharField(max_length=150)
    city  = models.CharField(max_length=150)
    street = models.CharField(max_length=150)
    customer = models.OneToOneField(Customer,on_delete=models.CASCADE,primary_key=True)






class Order(models.Model):
    ORDER_STATUS_PAID='p'
    ORDER_STATUS_UNPAID='u'
    ORDER_STATUS_CANCELED='c'
    ORDER_STATUS = [
        (ORDER_STATUS_PAID,'paid'),
        (ORDER_STATUS_UNPAID ,'unpaid'),
        (ORDER_STATUS_CANCELED ,'canceled'),
    ]
    customer = models.ForeignKey(Customer,on_delete=models.PROTECT,related_name='orders')
    datetime_created = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=6,choices=ORDER_STATUS,default=ORDER_STATUS_UNPAID)

    def __str__(self):
        return self.status


class OrderItem(models.Model):
    product = models.ForeignKey(Product,on_delete=models.PROTECT,related_name='orderitems')
    order = models.ForeignKey(Order,on_delete=models.CASCADE,related_name='orderitems')
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=6,decimal_places=2)

    class Meta:
        unique_together = [['order','product']]


class Comment(models.Model):
    COMMENT_STATUS_WAITING = 'w'
    COMMENT_STATUS_APPROVED = 'a'
    COMMENT_STATUS_NOT_APPROVED = 'na'
    COMMENT_STATUS = [
        (COMMENT_STATUS_WAITING,'waiting'),
        (COMMENT_STATUS_APPROVED,'approved'),
        (COMMENT_STATUS_NOT_APPROVED,'not approved'),
    ]
    product = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='comments')
    name = models.CharField(max_length=39)
    body = models.TextField()
    date_of_creation = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=30,
                              choices=COMMENT_STATUS,
                              default=COMMENT_STATUS_WAITING)

class Cart(models.Model):
    datetime_created = models.DateTimeField(auto_now_add=True)

class CartItem(models.Model):
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name='cartitems')
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='cartitems')
    quantity = models.PositiveIntegerField()


