from django.utils.http import urlencode
from django.contrib import admin, messages
from django.contrib import admin
from django.urls import reverse

from .models import Product, Category, Customer, Order,Comment,OrderItem
from django.utils.html import format_html


admin.site.site_header = 'Store site'
admin.site.index_title ='Store'

class InventoryFilter(admin.SimpleListFilter):
    title = 'critical inventory'
    parameter_name = 'inventory'
    def lookups(self, request, model_admin):
        return [
            ('<3','high'),
            ('3<=10','medium'),
            ('>10','low')
        ]
    def queryset(self, request, queryset):
        if self.value() == '<3':
            return queryset.filter(inventory__lt=3)
        if self.value() == '3<=10':
            return queryset.filter(inventory__range=(3,10))
        if self.value() == '>10':
            return queryset.filter(inventory__gt=10)


class CommentAdminInline(admin.TabularInline):
    model = Comment
    extra = 1
class ProductAdmin(admin.ModelAdmin):
    list_display = ['id','inventory','description','unit_price','inventory_status','product_category','comments']
    list_per_page = 10
    list_select_related = ['category']
    list_filter = ['datetime_created',InventoryFilter]
    actions = ('uppercase','lowercase','inventory_zero')
    inlines = (CommentAdminInline,)

    prepopulated_fields = {
        'slug': ['description',]
    }
    search_fields = ['description']

    @admin.action(description='Make selected product uppercase')
    def uppercase(modeladmin, request, queryset):
            for obj in queryset:
                obj.description = obj.description.upper()
                obj.save()
                messages.success(request, "Successfully made uppercase!")

    @admin.action(description='Make selected product lowercase')
    def lowercase(modeladmin, request, queryset):
            for obj in queryset:
                obj.description = obj.description.lower()
                obj.save()
                messages.success(request, "Successfully made lowercase!")

    @admin.action(description='make inventory zero')
    def inventory_zero(modeladmin,request,queryset):
        for obj in queryset:
            obj.inventory = 0
            obj.save()
            messages.success(request,'inventory become zero')


    def inventory_status(self,product):
        if product.inventory < 10 :
            return 'low'
        elif product.inventory < 50 and product.inventory > 10:
            return 'medium'
        else:
            return 'high'

    @admin.display(ordering='category__title')
    def product_category(self,product):
        return product.category.title

    @admin.display()
    def comments(self,product):
        url = (
            reverse('admin:store_comment_changelist')
        ) + '?' + urlencode({
            'product__id':product.id
        })
        return format_html('<a href="{}">{}</a>',url,product.comments.count())


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id','status','customer','datetime_created']
    list_per_page = 10


class CommentAdmin(admin.ModelAdmin):
    list_display = ['id','product','status']
    list_per_page = 10
    autocomplete_fields = ['product',]

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['first_name','last_name','email']
    ordering = ['first_name']
    list_per_page = 10
    search_fields = ['first_name','last_name']

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['title','description']
    list_display_links = ['title','description']


@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['product','order','quantity','unit_price']
    list_per_page = 10
    autocomplete_fields = ['product',]














admin.site.register(Product,ProductAdmin)
admin.site.register(Category,CategoryAdmin)
admin.site.register(Comment,CommentAdmin)




