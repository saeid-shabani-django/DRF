from django.core.management import BaseCommand

from store.management.commands import setup_fake_data

# Register MyCommand
BaseCommand.register_command(setup_fake_data.Command)